# Define the output directory
$MetricsDir = "E:\project\HPCAlertSystem\deploy\collectors\metrics"
New-Item -ItemType Directory -Force -Path $MetricsDir | Out-Null

# Function to collect GPU metrics
Function Collect-GpuUsage {
    $MetricsFile = "$MetricsDir\GPU_usage.prom"
    New-Item -ItemType File -Force -Path $MetricsFile | Out-Null

    # Execute nvidia-smi and parse the output
    $GpuMetrics = & nvidia-smi --query-gpu=index,utilization.gpu,utilization.memory --format=csv,noheader,nounits

    # Prepare Prometheus-compatible metrics
    $GpuUtilizationSamples = @()
    $GpuMemoryUtilizationSamples = @()

    foreach ($Line in $GpuMetrics) {
        $Fields = $Line -split ","
        $Index = $Fields[0].Trim()
        $GpuUtil = $Fields[1].Trim()
        $MemUtil = $Fields[2].Trim()

        $GpuUtilizationSamples += "gpu_utilization_percentage{gpu=`"$Index`"} $GpuUtil"
        $GpuMemoryUtilizationSamples += "gpu_memory_utilization_percentage{gpu=`"$Index`"} $MemUtil"
    }

    Set-Content -Path $MetricsFile -Value @(
        "# HELP gpu_utilization_percentage The current GPU utilization percentage.`n"
        "# TYPE gpu_utilization_percentage gauge`n"
        $GpuUtilizationSamples
        "`n`n"
        "# HELP gpu_memory_utilization_percentage The current GPU memory utilization percentage.`n"
        "# TYPE gpu_memory_utilization_percentage gauge`n"
        $GpuMemoryUtilizationSamples
        "`n"
    ) -NoNewline

}

# Main loop
While ($true) {
    Collect-GpuUsage
    Start-Sleep -Seconds 1
}
