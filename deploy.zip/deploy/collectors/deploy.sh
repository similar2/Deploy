#!/bin/bash
set -e  # Exit immediately if a command exits with a non-zero status

# Directory paths
COLLECTORS_DIR="."

echo "Starting deployment of monitoring node..."

# Step 1: Start Docker containers
echo "Bringing up Docker containers..."
docker-compose up -d
echo "Docker containers are up and running."

# Step 2: Start custom metric scraper scripts (if any)
if [ -d "$COLLECTORS_DIR" ]; then
    echo "Starting custom metric scraper scripts..."
    for script in "$COLLECTORS_DIR"/*.sh; do
        if [[ -f "$script" ]]; then
            chmod +x "$script"
            echo "Running $script in the background using nohup..."
            nohup "$script" > "$(basename "$script").log" 2>&1 &
        else
            echo "Skipping $script (not a valid file)"
        fi
    done
    echo "All custom scripts in $COLLECTORS_DIR have been started in the background."
else
    echo "No collectors directory found. Skipping custom scripts."
fi

echo "Deployment completed successfully!"
